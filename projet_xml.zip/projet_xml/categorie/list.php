<?php 
    include("../fonctions.php");
    $list_categories = get_all_categories();
?>