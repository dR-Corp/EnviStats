<?php 
    include("../fonctions.php");
    $list_categories = get_all_indicateurs();
?>