<?php 
    include("../fonctions.php");
    $list_categories = get_all_sous_categories();
?>