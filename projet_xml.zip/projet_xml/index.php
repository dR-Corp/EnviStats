<?php
    include('fonctions.php');
?>

<!-- cette page contiendra le dashboard qui ici est l apge d'accueil et sera le point d'entré de l'appplication, le home controller en gros -->